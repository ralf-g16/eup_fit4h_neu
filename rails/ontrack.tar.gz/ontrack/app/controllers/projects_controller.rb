class ProjectsController < ApplicationController
		def index
			@projects = Project.all
		end

		def show
			@project = Project.find(params[:id])
		end

		def edit
			@project = Project.find(params[:id])
		end

		def new
			@project = Project.new
		end

		def update
			@project = Project.find(params[:id])
			if @project.update(project_params)
			flash[:notice] = "gut gespeichert ist halb gewonnen."
			redirect_to project_path(@project.id)
			else
				render "edit"
			end	
		end

		def create
			@project = Project.new(project_params)
			if @project.save
				flash[:notice] = "gut gespeichert ist halb gewonnen."
				redirect_to project_path(@project.id)
			else
				render "new"
			end
		end

		def destroy
			@project = Project.find(params[:id])
			if @project.destroy
				flash[:notice] = "endlich gelöscht."
				redirect_to projects_url
			end
		end

		private
			def project_params
				params.require(:project).permit(:title, :start_date, :description)
			end
end
