class TasksController < ApplicationController
  before_action :set_task, only: [:show, :edit, :update, :destroy]
  before_action :set_project
  def index
    #@tasks = Task.where(project_id: params[:project_id])
    @tasks = @project.tasks
  end

  def new
    @tasks = @project.tasks.new
  end

  def create
    @tasks = @project.tasks.new(task_params)
    if @tasks.save
      #@flash[:notice] = "Registrierung erfolgreich"
      redirect_to project_path(@project.id), notice: "Registrierung erfolgreich!"
    else
      render "new"
    end

  end

  private

  def set_project
    @project = Event.find(params[:project_id])    
  end

  def set_project
    @project = Project.find(params[:project_id])
  end
  
    # Never trust parameters from the scary internet, only allow the white list through.
  def task_params
      params.require(:task).permit(:title, :description, :start_date, :end_date, :project_id)
   end
end
